from flask import Flask, request, render_template
import os
import subprocess
import time

app = Flask(__name__)


PORT_FILE = "current_port.txt"

def get_current_port():
    # Check if the port file exists
    if os.path.exists(PORT_FILE):
        # Read the current port number from the file
        with open(PORT_FILE, "r") as f:
            return int(f.read().strip())
    else:
        # If the file doesn't exist, start from port 5000
        return 5000

@app.route('/')
def index():
    return render_template('index.html')

def fun():
    return render_template('deployed.html')



@app.route('/deploy', methods=['POST'])
def deploy_function():
    # Trigger code when the deploy button is clicked
    print("Deploy button clicked!")
    fun()
    subprocess.run(['bash', "run.sh"], check=True)
    # time.sleep(300)

    return " Deployinggggg function..."

    

@app.route('/delete', methods=['POST'])
def delete_function():
    # Trigger code when the delete button is clicked
    print("Delete button clicked!")
    return "Deleting function..."


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5002))
    app.run(debug=True, host='0.0.0.0', port=port)
